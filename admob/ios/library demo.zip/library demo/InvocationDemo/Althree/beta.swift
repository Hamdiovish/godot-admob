//
//  beta.swift
//  Althree
//
//  Created by Hamdy BEN SALAH on 10/26/20.
//

import Foundation
import AdMobA

@objc open class AlphaA : NSObject {

    @objc public func printSome(data:String) {
        let a = AdMobA()
        a.printSome(data: "Fully Swift Static Lib")
    }
}
