//
//  AppDelegate.h
//  Althree
//
//  Created by Hamdy BEN SALAH on 10/26/20.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

