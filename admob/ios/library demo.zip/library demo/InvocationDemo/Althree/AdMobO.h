//
//  AdMobO.h
//  AdMobO
//
//  Created by Hamdy BEN SALAH on 10/26/20.
//

#import <Foundation/Foundation.h>

@interface AdMobO : NSObject

+ (void) alpha;
+ (void) beta;
+ (void) gama;

@end
