//
//  ViewController.m
//  Althree
//
//  Created by Hamdy BEN SALAH on 10/26/20.
//

#import "ViewController.h"
#import "AdMob/AdMob-Swift.h"
#import "AdMobO.h"
#import "Althree-Swift.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSLog(@">>Swift Framework Call:");
    Alphin * alp = [[Alphin alloc] init];
    [alp printSomeWithData :@"yeppi!"];
    
    NSLog(@">>ObjC Static LIbrary Call:");
    [AdMobO alpha];
    [AdMobO beta];
    
    NSLog(@">>Swift Static Library Call:");
    AlphaA * alpA = [[AlphaA alloc] init];
    [alpA printSomeWithData :@"yeppi yeppi!"];
}


@end
