//
//  AdMobA.swift
//  AdMobA
//
//  Created by Hamdy BEN SALAH on 10/26/20.
//

import Foundation

@objc open class AdMobA : NSObject {

    @objc public func printSome(data:String) {
        print(">>ALPHIN static swift library:",data);
    }
    
}
