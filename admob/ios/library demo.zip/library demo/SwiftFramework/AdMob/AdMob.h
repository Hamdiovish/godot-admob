//
//  AdMob.h
//  AdMob
//
//  Created by Hamdy BEN SALAH on 10/26/20.
//

#import <Foundation/Foundation.h>

//! Project version number for AdMob.
FOUNDATION_EXPORT double AdMobVersionNumber;

//! Project version string for AdMob.
FOUNDATION_EXPORT const unsigned char AdMobVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AdMob/PublicHeader.h>


