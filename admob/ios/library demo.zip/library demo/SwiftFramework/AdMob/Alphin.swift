//
//  Alphin.swift
//  AdMob
//
//  Created by Hamdy BEN SALAH on 10/26/20.
//

import Foundation

@objc open class Alphin : NSObject {

    @objc public func printSome(data:String) {
        print(">>ALPHIN:",data);
    }
    
}
