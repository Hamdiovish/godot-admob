//
//  Alphin.swift
//  AdMobO
//
//  Created by Hamdy BEN SALAH on 10/26/20.
//

import Foundation

@objc open class Alphin : NSObject {

    @objc public func printSome(data:String) {
        print(">>ALPHIN:",data);
    }

    @objc public func callObjC() {
        print(">>ALPHIN: I'll call ObjC now:");
        AdMobO.gama()
    }
}
