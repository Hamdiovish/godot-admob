//
//  AdMobO.m
//  AdMobO
//
//  Created by Hamdy BEN SALAH on 10/26/20.
//

#import "AdMobO.h"
#import "AdMobO-Swift.h"

@implementation AdMobO

+ (void) alpha {
    Alphin * alp = [[Alphin alloc] init];
    [alp printSomeWithData :@"yeppi!"];
}

+ (void) beta {
    Alphin * alp = [[Alphin alloc] init];
    [alp callObjC];
}

+ (void) gama {
    NSLog(@">>gama: Called in ObjC from swift:");
}

@end
